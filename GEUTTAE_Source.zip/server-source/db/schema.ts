import { integer, sqliteTable, text } from 'drizzle-orm/sqlite-core';
export const journals=sqliteTable('journals',{owner:text('owner').primaryKey(),content:text('content').notNull(),version:integer('version').notNull().default(0)});
