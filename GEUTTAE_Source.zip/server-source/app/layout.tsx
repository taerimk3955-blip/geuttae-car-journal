import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'그때 — 내 차의 순간 기록',description:'설명하기 어려웠던 내 차의 신호, 그때가 기억할게요.',icons:{icon:'/favicon.svg'}};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="ko"><body>{children}</body></html>}
