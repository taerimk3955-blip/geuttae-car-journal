import { getChatGPTUser } from '../../chatgpt-auth';
import { getDb } from '../../../db';
import { journals } from '../../../db/schema';
import { and, eq } from 'drizzle-orm';
import { journalInput } from '../../../lib/validation';
export async function GET(){
 const user=await getChatGPTUser();if(!user)return Response.json({error:'로그인이 필요합니다.'},{status:401});
 const row=await getDb().select().from(journals).where(eq(journals.owner,user.userId)).get();
 return Response.json({data:row?JSON.parse(row.content):null,version:row?.version??0,name:user.fullName||'드라이버'},{headers:{'Cache-Control':'no-store'}});
}
export async function PUT(req:Request){
 const user=await getChatGPTUser();if(!user)return Response.json({error:'로그인이 필요합니다.'},{status:401});
 try{const parsed=journalInput.safeParse(await req.json());if(!parsed.success)return Response.json({error:'입력한 기록 형식을 확인해주세요.'},{status:400});const {data,version}=parsed.data;
 const content=JSON.stringify(data);if(content.length>1500000)return Response.json({error:'기록 크기를 초과했습니다.'},{status:413});
 const db=getDb();const row=await db.select().from(journals).where(eq(journals.owner,user.userId)).get();
 if(!row){if(version!==0)return Response.json({error:'새로고침 후 다시 시도해주세요.'},{status:409});await db.insert(journals).values({owner:user.userId,content,version:1}).onConflictDoNothing();const saved=await db.select().from(journals).where(eq(journals.owner,user.userId)).get();if(saved?.content!==content)return Response.json({error:'다른 창에서 기록이 변경되었습니다.'},{status:409});return Response.json({version:1});}
 const updated=await db.update(journals).set({content,version:version+1}).where(and(eq(journals.owner,user.userId),eq(journals.version,version))).returning();
 if(!updated.length)return Response.json({error:'다른 창에서 기록이 변경되었습니다. 새로고침 후 다시 시도해주세요.'},{status:409});return Response.json({version:version+1});
 }catch{return Response.json({error:'저장하지 못했습니다. 다시 시도해주세요.'},{status:500});}
}
