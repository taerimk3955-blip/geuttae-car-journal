import {spawnSync} from 'node:child_process';
import {existsSync,readFileSync,writeFileSync,mkdirSync,readdirSync} from 'node:fs';
function run(args){const r=spawnSync(process.execPath,args,{stdio:'inherit'});if(r.error)throw r.error;if(r.status!==0)process.exit(r.status??1);}
run(['scripts/run-framework.mjs','build']);
mkdirSync('.wrangler',{recursive:true});
const marker='.wrangler/geuttae-local-migrations.json';
const applied=existsSync(marker)?JSON.parse(readFileSync(marker,'utf8')):[];
for(const file of readdirSync('drizzle').filter(x=>x.endsWith('.sql')).sort()){
 if(applied.includes(file))continue;
 run(['node_modules/wrangler/bin/wrangler.js','d1','execute','DB','--local','--config','dist/server/wrangler.json','--persist-to','.wrangler/state','--file','drizzle/'+file]);
 applied.push(file);writeFileSync(marker,JSON.stringify(applied));
}
console.log('준비 완료. npm run dev 를 실행하고 http://localhost:5173 에 접속하세요.');
