#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${ANDROID_HOME:?Set ANDROID_HOME to an Android SDK with platform 35 and build-tools 35.0.0}"
: "${GEUTTAE_KEYSTORE:?Set GEUTTAE_KEYSTORE to your release keystore path}"
: "${GEUTTAE_STORE_PASSWORD:?Set GEUTTAE_STORE_PASSWORD}"
: "${GEUTTAE_KEY_PASSWORD:?Set GEUTTAE_KEY_PASSWORD}"
GEUTTAE_KEY_ALIAS="${GEUTTAE_KEY_ALIAS:-geuttae}"
GEUTTAE_TEAM="${GEUTTAE_TEAM:-GEUTTAE}"
BT="$ANDROID_HOME/build-tools/35.0.0"
AJ="$ANDROID_HOME/platforms/android-35/android.jar"
TMP=android/app/build/manual
mkdir -p "$TMP/compiled" "$TMP/classes" "$TMP/generated/kr/geuttae/journal" apk
printf 'package kr.geuttae.journal; public final class BuildConfig { public static final boolean DEBUG = false; }\n' > "$TMP/generated/kr/geuttae/journal/BuildConfig.java"
"$BT/aapt2" compile --dir android/app/src/main/res -o "$TMP/compiled/"
sed 's/<manifest /<manifest package="kr.geuttae.journal" /' android/app/src/main/AndroidManifest.xml > "$TMP/AndroidManifest.xml"
"$BT/aapt2" link -o "$TMP/resources.apk" --manifest "$TMP/AndroidManifest.xml" -I "$AJ" --java "$TMP/generated" --min-sdk-version 29 --target-sdk-version 34 --version-code 1 --version-name 1.0.0 -A android/app/src/main/assets "$TMP"/compiled/*.flat
find android/app/src/main/java "$TMP/generated" -name '*.java' -print > "$TMP/sources.txt"
if [ -n "${GEUTTAE_ECJ:-}" ]; then
  java -jar "$GEUTTAE_ECJ" -1.8 -encoding UTF-8 -bootclasspath "$AJ:$BT/core-lambda-stubs.jar" -d "$TMP/classes" @"$TMP/sources.txt"
else
  javac -encoding UTF-8 -source 8 -target 8 -classpath "$AJ:$BT/core-lambda-stubs.jar" -d "$TMP/classes" @"$TMP/sources.txt"
fi
python3 - "$TMP" <<'PYJAR'
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import sys
p=Path(sys.argv[1])
with ZipFile(p/'classes.jar','w',ZIP_DEFLATED) as z:
 for f in (p/'classes').rglob('*.class'):z.write(f,str(f.relative_to(p/'classes')))
PYJAR
"$BT/d8" --release --min-api 29 --lib "$AJ" --output "$TMP" "$TMP/classes.jar"
python3 - "$TMP" <<'PY'
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import sys
p=Path(sys.argv[1])
with ZipFile(p/'resources.apk') as src, ZipFile(p/'unsigned.apk','w',ZIP_DEFLATED) as dst:
 for item in src.infolist():dst.writestr(item,src.read(item.filename))
 dst.write(p/'classes.dex','classes.dex')
PY
"$BT/zipalign" -f -p 4 "$TMP/unsigned.apk" "$TMP/aligned.apk"
"$BT/apksigner" sign --ks "$GEUTTAE_KEYSTORE" --ks-key-alias "$GEUTTAE_KEY_ALIAS" --ks-pass env:GEUTTAE_STORE_PASSWORD --key-pass env:GEUTTAE_KEY_PASSWORD --out "apk/${GEUTTAE_TEAM}_그때_release.apk" "$TMP/aligned.apk"
"$BT/apksigner" verify --verbose "apk/${GEUTTAE_TEAM}_그때_release.apk"
