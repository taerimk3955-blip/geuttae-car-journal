import React from 'react';
import {createRoot} from 'react-dom/client';
import App from './App';
// Compatibility with older Android System WebView builds.
if (!crypto.randomUUID) Object.defineProperty(crypto,'randomUUID',{value:()=>{
 const b=crypto.getRandomValues(new Uint8Array(16));b[6]=(b[6]&15)|64;b[8]=(b[8]&63)|128;
 const h=Array.from(b,x=>x.toString(16).padStart(2,'0')).join('');return `${h.slice(0,8)}-${h.slice(8,12)}-${h.slice(12,16)}-${h.slice(16,20)}-${h.slice(20)}`;
}});
if (!Response.json) Response.json=(body:any,init:any={})=>new Response(JSON.stringify(body),{...init,headers:{'Content-Type':'application/json',...init.headers}});
const nativeFetch=window.fetch.bind(window);
const openDB=()=>new Promise<IDBDatabase>((resolve,reject)=>{const r=indexedDB.open('geuttae-preview-files',1);r.onupgradeneeded=()=>r.result.createObjectStore('files');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});
async function fileOp(mode:IDBTransactionMode,id:string,value?:any){const db=await openDB();return await new Promise<any>((resolve,reject)=>{const tx=db.transaction('files',mode);const store=tx.objectStore('files');const r=value!==undefined?store.put(value,id):mode==='readwrite'?store.delete(id):store.get(id);let result:any;r.onsuccess=()=>result=r.result;tx.oncomplete=()=>{db.close();resolve(result)};tx.onerror=()=>{db.close();reject(tx.error)}})}
window.fetch=async(input:any,init:any={})=>{
 const raw=typeof input==='string'?input:input.url||String(input);
 if(!raw.startsWith('/api/'))return nativeFetch(input,init);
 try{
 const method=init.method||'GET';const u=new URL(raw,'https://local.invalid');
 if(u.pathname==='/api/journal'){
 const saved=JSON.parse(localStorage.getItem('geuttae-preview-journal')||'null');
 if(method==='GET')return Response.json({data:saved?.data||null,version:saved?.version||0,name:'드라이버'});
 const next=JSON.parse(init.body);if((saved?.version||0)!==next.version)return Response.json({error:'다른 창에서 기록이 변경됐어요. 새로고침해주세요.'},{status:409});
 localStorage.setItem('geuttae-preview-journal',JSON.stringify({data:next.data,version:next.version+1}));return Response.json({version:next.version+1});
 }
 if(u.pathname==='/api/files'){
 if(method==='POST'){const f=init.body.get('file');if(f.size>10*1024*1024)return Response.json({error:'파일은 10MB 이하로 첨부해주세요.'},{status:400});const id=crypto.randomUUID();await fileOp('readwrite',id,f);return Response.json({id,name:f.name,type:f.type})}
 const id=u.searchParams.get('id')||'';
 if(method==='DELETE'){await fileOp('readwrite',id);return Response.json({ok:true})}
 const f=await fileOp('readonly',id);return f?new Response(f,{headers:{'Content-Type':f.type}}):new Response('Not found',{status:404});
 }
 return new Response('Not found',{status:404});
 }catch{return Response.json({error:'브라우저 저장소를 사용할 수 없어요. 일반 브라우저에서 파일을 열어주세요.'},{status:500})}
};
// Local file media URLs use blob URLs because file:// has no HTTP API server.
const originalCreate=React.createElement;
createRoot(document.getElementById('root')!).render(<App/>);
