package kr.geuttae.journal;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.util.Base64;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;
import java.util.*;

/** Offline Android host for the existing Geuttae application. */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START = "https://" + HOST + "/assets/www/index.html";
    private static final int AUDIO_PERMISSION = 10, PICK_FILE = 11, SAVE_FILE = 12;
    private WebView web;
    private PermissionRequest pendingAudio;
    private ValueCallback<Uri[]> fileCallback;
    private byte[] pendingExport;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true); // System picker supplies only user-selected content URIs.
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        if (android.os.Build.VERSION.SDK_INT >= 26) settings.setSafeBrowsingEnabled(true);
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        web.addJavascriptInterface(new HostBridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("https".equals(u.getScheme()) && HOST.equals(u.getHost()) && u.getPath() != null && u.getPath().startsWith("/assets/www/")) {
                    String path = u.getPath().substring("/assets/".length());
                    if (path.contains("..")) return unavailable();
                    try {
                        String mime = path.endsWith(".html") ? "text/html" : path.endsWith(".js") ? "application/javascript" : path.endsWith(".css") ? "text/css" : "application/octet-stream";
                        return new WebResourceResponse(mime, "UTF-8", getAssets().open(path));
                    } catch (IOException e) { return unavailable(); }
                }
                // No external network resources are required by this build.
                return unavailable();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                return !("https".equals(u.getScheme()) && HOST.equals(u.getHost()));
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    if (!request.getOrigin().toString().equals("https://" + HOST) && !request.getOrigin().toString().equals("https://" + HOST + "/")) { request.deny(); return; }
                    if (!Arrays.asList(request.getResources()).contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) { request.deny(); return; }
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    else { if (pendingAudio != null) pendingAudio.deny(); pendingAudio = request; requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, AUDIO_PERMISSION); }
                });
            }
            @Override public void onPermissionRequestCanceled(PermissionRequest request) { if (pendingAudio == request) pendingAudio = null; }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    String[] types = params.getAcceptTypes();
                    String type = types.length == 1 && !types[0].isEmpty() ? types[0] : "*/*";
                    intent.setType(type);
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                    startActivityForResult(intent, PICK_FILE);
                    return true;
                } catch (Exception e) { fileCallback = null; callback.onReceiveValue(null); return true; }
            }
        });
        web.loadUrl(START);
    }
    private WebResourceResponse unavailable() { return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", Collections.emptyMap(), new ByteArrayInputStream(new byte[0])); }
    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == AUDIO_PERMISSION && pendingAudio != null) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) pendingAudio.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            else pendingAudio.deny();
            pendingAudio = null;
        }
    }
    @Override protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == PICK_FILE && fileCallback != null) {
            ArrayList<Uri> selected = new ArrayList<>();
            if (result == RESULT_OK && data != null) {
                if (data.getClipData() != null) for (int i = 0; i < data.getClipData().getItemCount(); i++) selected.add(data.getClipData().getItemAt(i).getUri());
                else if (data.getData() != null) selected.add(data.getData());
            }
            fileCallback.onReceiveValue(selected.isEmpty() ? null : selected.toArray(new Uri[0]));
            fileCallback = null;
        }
        if (code == SAVE_FILE) {
            byte[] bytes = pendingExport;
            pendingExport = null;
            if (result == RESULT_OK && data != null && data.getData() != null && bytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new IOException("No output stream");
                    out.write(bytes); toast("파일을 저장했어요.");
                } catch (IOException e) { toast("파일을 저장하지 못했어요."); }
            }
        }
    }
    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_SHORT).show(); }
    private class HostBridge {
        @JavascriptInterface public void printReport() {
            runOnUiThread(() -> {
                PrintManager manager = (PrintManager)getSystemService(PRINT_SERVICE);
                if (manager != null) manager.print("그때 정비 전달 보고서", web.createPrintDocumentAdapter("그때 정비 전달 보고서"), new PrintAttributes.Builder().build());
            });
        }
        @JavascriptInterface public void exportFile(String name, String type, String base64) {
            if (base64 == null || base64.length() > 20 * 1024 * 1024) return;
            final byte[] bytes;
            try { bytes = Base64.decode(base64, Base64.DEFAULT); } catch (Exception e) { return; }
            runOnUiThread(() -> {
                if (pendingExport != null) { toast("저장 위치를 먼저 선택해 주세요."); return; }
                pendingExport = bytes;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(type == null || type.isEmpty() ? "application/octet-stream" : type);
                intent.putExtra(Intent.EXTRA_TITLE, name.replaceAll("[/\\\\]", "_"));
                try { startActivityForResult(intent, SAVE_FILE); } catch (Exception e) { pendingExport = null; toast("파일 저장 기능을 사용할 수 없어요."); }
            });
        }
    }
    @Override public void onBackPressed() {
        web.evaluateJavascript("(()=>{const b=document.querySelector('.modal [aria-label=닫기]');if(b){b.click();return true;}return false;})()", result -> { if (!"true".equals(result)) { if (web.canGoBack()) web.goBack(); else MainActivity.super.onBackPressed(); } });
    }
    @Override protected void onPause() { web.evaluateJavascript("document.dispatchEvent(new Event('geuttae:pause'))", null); web.onPause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }
    @Override protected void onDestroy() { if (pendingAudio != null) pendingAudio.deny(); if (fileCallback != null) fileCallback.onReceiveValue(null); web.removeJavascriptInterface("AndroidBridge"); web.destroy(); super.onDestroy(); }
}
