/* Android-only host integration. The web application remains offline-first. */
(()=>{
 if(!window.AndroidBridge)return;
 window.print=()=>AndroidBridge.printReport();
 document.addEventListener('click',async e=>{
  const a=e.target.closest?.('a[download]');
  if(!a||!a.href.startsWith('blob:'))return;
  e.preventDefault();e.stopImmediatePropagation();
  try{
   const blob=await (await fetch(a.href)).blob();
   const reader=new FileReader();reader.onload=()=>AndroidBridge.exportFile(a.download||'그때_파일',blob.type||'application/octet-stream',String(reader.result).split(',')[1]);reader.readAsDataURL(blob);
  }catch{alert('파일을 저장하지 못했어요. 다시 시도해 주세요.')}
 },true);
 const ActiveRecorder=window.MediaRecorder,active=new Set();
 if(ActiveRecorder){window.MediaRecorder=new Proxy(ActiveRecorder,{construct(T,args){const r=new T(...args);active.add(r);r.addEventListener('stop',()=>active.delete(r));return r}})}
 document.addEventListener('geuttae:pause',()=>{active.forEach(r=>{if(r.state==='recording')r.stop();r.stream.getTracks().forEach(t=>t.stop())})});
})();
